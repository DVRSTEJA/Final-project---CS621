from django.contrib import admin
from .models import CustomUser, Book, BorrowingList, Borrowing

admin.site.register(CustomUser)
admin.site.register(Book)
admin.site.register(BorrowingList)
admin.site.register(Borrowing)