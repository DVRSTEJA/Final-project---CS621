from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from django.contrib import admin
from . import views


urlpatterns = [
    path('', views.login_view, name='login'),
    path('home/', views.home_view, name='home'),
    path('signup/', views.sign_up_view, name='sign_up'),
    path('logout/', views.logout_view, name='logout'),
    path('thankyou/', views.thankyou_view, name='thankyou'),
    path('upload_book/', views.upload_book_view, name='upload_book'),
    path('book/<int:pk>/', views.book_detail, name='book_detail'),
    path('borrow_book/<int:book_id>/', views.borrow_book_view, name='borrow_book'),
    path('return_book/<int:borrowing_id>/', views.return_book_view, name='return_book'),
    path('view_borrowing_list/', views.view_borrowing_list, name='view_borrowing_list'),
    path('borrowing_history/', views.borrowing_history_view, name='borrowing_history'),
    path('borrowing_history_user/', views.borrowing_history_user_view, name='borrowing_history_user'),
    path('search/', views.search_books, name='search_books'),
    path('current_borrowings/', views.current_borrowings_view, name='current_borrowings'),
    path('fines/', views.fines_view, name='fines'),
    path('account_details/', views.account_details_view, name='account_details'),
    path('user_accounts/', views.user_accounts_view, name='user_accounts'),
    path('fines_user/<int:user_id>/', views.fines_user_view, name='fines_user'),
    path('send_notification/<int:user_id>/', views.send_notification_view, name='send_notification'),
    path('add_book/', views.add_book_view, name='add_book'),
    path('add_to_cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('process_checkout/', views.process_checkout, name='process_checkout'),
    path('checkout_success/', views.checkout_success, name='checkout_success'),
    path('remove_from_cart/<int:book_id>/', views.remove_from_cart, name='remove_from_cart'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
