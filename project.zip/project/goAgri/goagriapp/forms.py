import re

from django import forms
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Book

class CustomUserForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'first_name', 'last_name', 'phone', 'address', 'is_librarian']

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = ['title', 'author', 'description', 'isbn', 'available_copies', 'total_copies', 'image']

class CustomUserRegistrationForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'first_name', 'last_name', 'phone', 'address', 'is_librarian']



# class CustomUserRegistrationForm(forms.ModelForm):
#     password1 = forms.CharField(label='Password', widget=forms.PasswordInput)
#     password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput)
#
#     class Meta:
#         model = custom_users
#         fields = ['username', 'email', 'first_name', 'last_name', 'phone', 'address', 'is_farmer']
#
#     def clean_password1(self):
#         password1 = self.cleaned_data.get('password1')
#         try:
#             validate_password(password1)
#         except ValidationError as validation_error:
#             raise forms.ValidationError(", ".join(validation_error))
#
#         # Additional password requirements using regular expressions
#         if not re.search(r'[A-Z]', password1):
#             raise forms.ValidationError("Password must have a single upper-case letter.")
#         if not re.search(r'[a-z]', password1):
#             raise forms.ValidationError("Password must have a single lower-case letter.")
#         if not re.search(r'\d$', password1):
#             raise forms.ValidationError("Password must end with a number.")
#
#         return password1
#
#     def clean_password2(self):
#         password1 = self.cleaned_data.get('password1')
#         password2 = self.cleaned_data.get('password2')
#
#         if password1 and password2 and password1 != password2:
#             raise forms.ValidationError("Passwords do not match.")
#
#         return password2
#
#     def save(self, commit=True):
#         user = super().save(commit=False)
#         password = self.cleaned_data['password1']
#         user.set_password(password)
#
#         if commit:
#             user.save()
#
#         return user