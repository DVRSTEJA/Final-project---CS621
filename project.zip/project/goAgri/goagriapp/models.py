from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone

class CustomUser(AbstractUser):
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=10)
    address = models.CharField(max_length=255)
    is_librarian = models.BooleanField(default=False)

class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255)
    description = models.TextField()
    isbn = models.CharField(max_length=13, unique=True)
    available_copies = models.PositiveIntegerField(default=1)
    total_copies = models.PositiveIntegerField(default=1)
    quantity_to_borrow = models.PositiveIntegerField(default=1)
    image = models.ImageField(upload_to='media/files/book_images',
                              default='media/files/book_images/default_book_image.jpg')

    def __str__(self):
        return self.title

class BorrowingList(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    books = models.ManyToManyField(Book, through='Borrowing')
    borrowed_at = models.DateTimeField(default=timezone.now)
    returned_at = models.DateTimeField(null=True, blank=True)

class Borrowing(models.Model):
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    borrowing_list = models.ForeignKey(BorrowingList, on_delete=models.CASCADE)
    borrowed_at = models.DateTimeField(default=timezone.now)
    due_date = models.DateTimeField()
    returned_at = models.DateTimeField(null=True, blank=True)
    fine = models.PositiveIntegerField(default=0)

    def is_overdue(self):
        if self.returned_at:
            return False
        return timezone.now() > self.due_date

    def __str__(self):
        return f"{self.book.title} borrowed by {self.borrowing_list.user.username}"


class Cart(models.Model):

    objects = models.Manager()
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)
    books = models.ManyToManyField(Book)

    def __str__(self):
        return f"Cart for {self.user.username}"