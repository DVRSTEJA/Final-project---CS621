from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from .forms import CustomUserForm, CustomUserRegistrationForm, BookForm
from django.utils import timezone
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from .models import Book, BorrowingList, Borrowing, CustomUser, Cart
from django.db.models import Q
from django.core.mail import send_mail
from django.contrib.auth.decorators import login_required, user_passes_test


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})


def sign_up_view(request):
    if request.method == 'POST':
        form = CustomUserRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thankyou')
    else:
        form = CustomUserRegistrationForm()
    return render(request, 'signup.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def home_view(request):
    books = Book.objects.all()
    return render(request, 'home.html',
                  {'books': books, 'is_librarian': request.user.is_authenticated and request.user.is_librarian})

@login_required
def thankyou_view(request):
    return render(request, 'thankyou.html')


@user_passes_test(lambda u: u.is_librarian)
def upload_book_view(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BookForm()
    return render(request, 'upload_book.html', {'form': form})

@login_required
def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'book_detail.html',
                  {'book': book, 'is_librarian': request.user.is_authenticated and request.user.is_librarian})


@login_required
def borrow_book_view(request, book_id):
    book = get_object_or_404(Book, pk=book_id)
    if request.user.is_librarian:
        messages.error(request, 'Librarians cannot borrow books.')
        return redirect('book_detail', pk=book_id)

    if book.available_copies > 0:
        borrowing_list, created = BorrowingList.objects.get_or_create(user=request.user, returned_at__isnull=True)
        Borrowing.objects.create(borrowing_list=borrowing_list, book=book,
                                 due_date=timezone.now() + timezone.timedelta(days=14))
        book.available_copies -= 1
        book.save()
        messages.success(request, 'Book borrowed successfully!')
    else:
        messages.error(request, 'No available copies of this book.')

    return redirect('book_detail', pk=book_id)



@login_required
def add_to_cart(request, book_id):
    book = get_object_or_404(Book, pk=book_id)
    if request.user.is_librarian:
        messages.error(request, 'Librarians cannot borrow books.')
        return redirect('home')

    cart, created = Cart.objects.get_or_create(user=request.user)

    cart_book = cart.books.filter(pk=book_id).first()
    if cart_book:
        cart_book.quantity_to_borrow += 1
        cart_book.save()
        messages.success(request, f'{book.title} quantity increased in the cart.')
    else:
        cart.books.add(book)
        messages.success(request, f'{book.title} added to the cart.')

    # messages.success(request, f'{crop.name} successfully added to the cart.')

    return redirect('home')


@login_required
def checkout(request):
    if request.user.is_librarian:
        messages.error(request, 'Librarians cannot checkout books.')
        return redirect('home')

    cart, created = Cart.objects.get_or_create(user=request.user)
    books = cart.books.all()
    print('*******************checkout')
    print(books)

    return render(request, 'checkout.html', {'books': books})


@login_required
def process_checkout(request):
    if request.user.is_librarian:
        messages.error(request, 'Librarians cannot checkout books.')
        return redirect('home')
    cart = Cart.objects.get(user=request.user)
    books = cart.books.all()
    print('****************************************8process_checkout')
    print(books)
    print(cart.books)
    print(cart)
    if len(books) == 0:
        messages.error(request, "Cannot Checkout, The Cart is Empty!")
        return redirect('checkout')
    for book in books:
        if book.available_copies >= book.quantity_to_borrow:
            borrowing_list, created = BorrowingList.objects.get_or_create(user=request.user, returned_at__isnull=True)
            Borrowing.objects.create(borrowing_list=borrowing_list, book=book,
                                     due_date=timezone.now() + timezone.timedelta(days=14))
            book.available_copies -= book.quantity_to_borrow
            book.quantity_to_borrow = 1
            book.save()
        else:
            messages.error(request, f'Not Enough Copies Available for {book.title} By {book.author} Book Removed From Cart')
            book.quantity_to_borrow = 1
            book.save()

    cart.books.clear()

    return redirect('checkout_success')


@login_required
def checkout_success(request):
    return render(request, 'checkout_success.html')


@login_required
def remove_from_cart(request, book_id):
    if request.user.is_librarian:
        messages.error(request, 'Librarians cannot checkout books.')
        return redirect('home')
    cart = Cart.objects.get(user=request.user)
    book = get_object_or_404(Book, pk=book_id)
    book.quantity_to_borrow = 1
    book.save()
    cart.books.remove(book)
    return redirect('checkout')


@login_required
def view_borrowing_list(request):
    borrowing_list = BorrowingList.objects.filter(user=request.user, returned_at__isnull=True).first()
    borrowings = Borrowing.objects.filter(borrowing_list=borrowing_list, returned_at__isnull=True)
    return render(request, 'borrowing_list.html', {'borrowings': borrowings})


def search_books(request):
    query = request.GET.get('q')
    results = Book.objects.filter(Q(title__icontains=query) | Q(author__icontains=query))
    return render(request, 'search_results.html', {'query': query, 'books': results})


@login_required
def borrowing_history_view(request):
    borrowings = Borrowing.objects.filter(borrowing_list__user=request.user)
    for borrowing in borrowings:
        if borrowing.returned_at is None and borrowing.due_date < timezone.now():
            borrowing.returned_at = 'Overdue'
    return render(request, 'borrowing_history.html', {'borrowings': borrowings})


@login_required
def current_borrowings_view(request):
    borrowings = Borrowing.objects.filter(borrowing_list__user=request.user, borrowing_list__returned_at__isnull=True)
    return render(request, 'current_borrowings.html', {'borrowings': borrowings})


@login_required
def fines_view(request):
    fines = Borrowing.objects.filter(borrowing_list__user=request.user, fine__gt=0)
    return render(request, 'fines.html', {'fines': fines})


@login_required
def account_details_view(request):
    return render(request, 'account_details.html', {'user': request.user})


@user_passes_test(lambda u: u.is_librarian)
def user_accounts_view(request):
    users = CustomUser.objects.all()
    return render(request, 'user_accounts.html', {'users': users})


@user_passes_test(lambda u: u.is_librarian)
def borrowing_history_user_view(request, user_id):
    user = get_object_or_404(CustomUser, pk=user_id)
    borrowings = Borrowing.objects.filter(borrowing_list__user=user)
    return render(request, 'borrowing_history_user.html', {'borrowings': borrowings, 'user': user})


@user_passes_test(lambda u: u.is_librarian)
def fines_user_view(request, user_id):
    user = get_object_or_404(CustomUser, pk=user_id)
    fines = Borrowing.objects.filter(borrowing_list__user=user, fine__gt=0)
    return render(request, 'fines_user.html', {'fines': fines, 'user': user})


@user_passes_test(lambda u: u.is_librarian)
def send_notification_view(request, user_id):
    user = get_object_or_404(CustomUser, pk=user_id)
    if request.method == 'POST':
        message = request.POST['message']
        send_mail(
            'Library Notification',
            message,
            'library@example.com',  # Replace with your sender email
            [user.email],
            fail_silently=False,
        )
        messages.success(request, f'Notification sent to {user.username}')
        return redirect('user_accounts')
    return render(request, 'send_notification.html', {'user': user})


@user_passes_test(lambda u: u.is_librarian)
def add_book_view(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Book added successfully!')
            return redirect('add_book')
    else:
        form = BookForm()
    return render(request, 'add_book.html', {'form': form})


@login_required
def return_book_view(request, borrowing_id):
    borrowing = get_object_or_404(Borrowing, pk=borrowing_id)
    if borrowing.borrowing_list.user != request.user:
        messages.error(request, 'You cannot return a book that you did not borrow.')
        return redirect('view_borrowing_list')

    borrowing.returned_at = timezone.now()
    borrowing.save()

    if borrowing.book.available_copies < borrowing.book.total_copies:
        borrowing.book.available_copies += 1
        borrowing.book.save()
    else:
        messages.warning(request, 'Available copies already at maximum. Cannot increment further.')

    messages.success(request, 'Book returned successfully!')
    return redirect('view_borrowing_list')


@user_passes_test(lambda u: u.is_librarian)
def borrowing_history_user_view(request):
    borrowings = Borrowing.objects.all().order_by('-borrowed_at')

    # Calculate fines for overdue borrowings
    fine_per_day = 5  # Define the fine amount per day for overdue books
    for borrowing in borrowings:
        if borrowing.returned_at is None and borrowing.due_date < timezone.now():
            days_overdue = (timezone.now() - borrowing.due_date).days
            borrowing.fine = days_overdue * fine_per_day
        elif borrowing.returned_at and borrowing.returned_at > borrowing.due_date:
            days_overdue = (borrowing.returned_at - borrowing.due_date).days
            borrowing.fine = days_overdue * fine_per_day
        else:
            borrowing.fine = 0
        borrowing.save()

    return render(request, 'borrowing_history_user.html', {'borrowings': borrowings})